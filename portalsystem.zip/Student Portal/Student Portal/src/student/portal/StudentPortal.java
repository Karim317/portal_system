
package student.portal;

public class StudentPortal{

   public static void main(String[] args) {
        
        Portal portal = new Portal();
        portal.start();
        
    }
}
    

