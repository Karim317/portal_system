
package student.portal;


public abstract  class Person {
    String ID;

    public Person(String ID) {
        this.ID = ID;
    }
    
}
